const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = 3000;

app.set('view engine', 'ejs');
app.use('/uploads', express.static(path.join(__dirname, 'public/uploads')));

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage: storage });

function getImages() {
    if (!fs.existsSync('uploads.json')) return [];
    const data = fs.readFileSync('uploads.json');
    return JSON.parse(data);
}

function saveImage(filename) {
    const images = getImages();
    images.push({ filename: filename, uploadedAt: new Date().toISOString() });
    fs.writeFileSync('uploads.json', JSON.stringify(images, null, 2));
}

app.get('/', (req, res) => {
    const images = getImages();
    res.render('index', { images });
});

app.get('/upload', (req, res) => {
    res.render('upload');
});

app.post('/upload', upload.single('image'), (req, res) => {
    if (req.file) {
        saveImage(req.file.filename);
        res.redirect('/');
    } else {
        res.send('لطفاً یک عکس انتخاب کن.');
    }
});

app.listen(PORT, () => {
    console.log(`سرور روی http://localhost:${PORT} اجرا شد`);
});